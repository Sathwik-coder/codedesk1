import { useState, useEffect, useCallback, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { createPad, getPad, updatePad } from '../utils/api'
import { useDebounce } from './useDebounce'

const DEFAULTS = {
  html: `<div class="card">
  <h1>Hello, CodeDesk! ✦</h1>
  <p>Edit HTML, CSS and JS — see changes instantly.</p>
  <button onclick="handleClick()">Click me</button>
</div>`,
  css: `* { box-sizing: border-box; margin: 0; padding: 0; }

body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #0d0d0f;
  font-family: 'DM Sans', system-ui, sans-serif;
}

.card {
  background: #141416;
  border: 1px solid #252528;
  border-radius: 12px;
  padding: 2rem 2.5rem;
  text-align: center;
  max-width: 400px;
}

h1 {
  font-size: 1.6rem;
  color: #e4e4e7;
  margin-bottom: 0.75rem;
}

p {
  color: #71717a;
  font-size: 0.95rem;
  margin-bottom: 1.5rem;
  line-height: 1.6;
}

button {
  background: #7c6af7;
  color: white;
  border: none;
  padding: 0.6rem 1.4rem;
  border-radius: 8px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: opacity 0.15s;
}

button:hover { opacity: 0.85; }`,
  js: `function handleClick() {
  const btn = document.querySelector('button');
  btn.textContent = '🎉 You clicked it!';
  setTimeout(() => btn.textContent = 'Click me', 1500);
}`,
}

export function usePad(padId) {
  const navigate = useNavigate()
  const [html, setHtml] = useState(DEFAULTS.html)
  const [css, setCss] = useState(DEFAULTS.css)
  const [js, setJs] = useState(DEFAULTS.js)
  const [currentPadId, setCurrentPadId] = useState(padId || null)
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(!!padId)
  const [error, setError] = useState(null)
  const isRemote = useRef(!!padId)

  // Load pad if id in URL
  useEffect(() => {
    if (!padId) return
    setLoading(true)
    getPad(padId)
      .then(({ data }) => {
        setHtml(data.html)
        setCss(data.css)
        setJs(data.js)
        setCurrentPadId(data.id)
        isRemote.current = true
      })
      .catch(() => setError('Pad not found. Starting fresh.'))
      .finally(() => setLoading(false))
  }, [padId])

  // Auto-save debounced
  const autoSave = useDebounce(async (id, h, c, j) => {
    if (!id) return
    setSaving(true)
    try {
      await updatePad(id, { html: h, css: c, js: j })
    } catch (_) {}
    setSaving(false)
  }, 1200)

  useEffect(() => {
    if (currentPadId) autoSave(currentPadId, html, css, js)
  }, [html, css, js, currentPadId])

  const share = useCallback(async () => {
    setSaving(true)
    try {
      const { data } = await createPad({ html, css, js })
      setCurrentPadId(data.id)
      navigate(`/${data.id}`, { replace: true })
      const url = `${window.location.origin}/${data.id}`
      await navigator.clipboard.writeText(url)
      setSaving(false)
      return url
    } catch (_) {
      setSaving(false)
      throw new Error('Share failed')
    }
  }, [html, css, js, navigate])

  const reset = useCallback(() => {
    setHtml(DEFAULTS.html)
    setCss(DEFAULTS.css)
    setJs(DEFAULTS.js)
  }, [])

  return {
    html, setHtml,
    css, setCss,
    js, setJs,
    currentPadId,
    saving, loading, error,
    share, reset,
  }
}
