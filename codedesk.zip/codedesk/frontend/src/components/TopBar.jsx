import React from 'react'

export default function TopBar({
  saving,
  autoRun,
  onToggleAutoRun,
  onRun,
  onShare,
  onReset,
  onDownload,
  currentPadId,
  isFullscreen,
  onToggleFullscreen,
}) {
  return (
    <header className="h-12 flex items-center justify-between px-4 border-b border-desk-border bg-desk-surface flex-shrink-0 z-20">
      {/* Logo */}
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 rounded-md bg-desk-accent/20 border border-desk-accent/30 flex items-center justify-center">
          <span className="text-desk-accent text-xs font-mono font-bold">&lt;/&gt;</span>
        </div>
        <span className="font-sans font-semibold text-desk-text tracking-tight text-[15px]">
          Code<span className="text-desk-accent">Desk</span>
        </span>
        {saving && (
          <span className="text-[10px] text-desk-muted font-mono animate-pulse ml-1">saving…</span>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2">
        {/* Auto-run toggle */}
        <button
          onClick={onToggleAutoRun}
          className={`btn text-xs gap-1.5 ${autoRun ? 'bg-desk-green/10 border border-desk-green/30 text-desk-green' : 'btn-ghost'}`}
          title="Toggle auto-run"
        >
          <span className={`w-1.5 h-1.5 rounded-full ${autoRun ? 'bg-desk-green' : 'bg-desk-muted'}`} />
          Auto
        </button>

        {/* Run */}
        <button onClick={onRun} className="btn-primary text-xs" title="Run code (Ctrl+Enter)">
          <svg width="11" height="11" viewBox="0 0 12 12" fill="currentColor">
            <path d="M2 1.5L10 6L2 10.5V1.5Z"/>
          </svg>
          Run
        </button>

        <div className="w-px h-5 bg-desk-border mx-0.5" />

        {/* Share */}
        <button onClick={onShare} className="btn-ghost text-xs" title="Share & copy link">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
            <circle cx="13" cy="3" r="1.5"/>
            <circle cx="3" cy="8" r="1.5"/>
            <circle cx="13" cy="13" r="1.5"/>
            <path d="M4.5 7.2L11.5 3.8M4.5 8.8L11.5 12.2" strokeLinecap="round"/>
          </svg>
          Share
        </button>

        {/* Download */}
        <button onClick={onDownload} className="btn-ghost text-xs" title="Download as HTML">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M8 3v7M5 8l3 3 3-3" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M3 13h10" strokeLinecap="round"/>
          </svg>
          Download
        </button>

        {/* Reset */}
        <button onClick={onReset} className="btn-ghost text-xs" title="Reset to defaults">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M3 8A5 5 0 1 1 5.5 12.5" strokeLinecap="round"/>
            <path d="M3 4.5V8.5H7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Reset
        </button>

        {/* Fullscreen */}
        <button onClick={onToggleFullscreen} className="btn-ghost text-xs px-2" title="Fullscreen editor">
          {isFullscreen ? (
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M6 2H2v4M10 2h4v4M6 14H2v-4M10 14h4v-4" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          ) : (
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M2 6V2h4M10 2h4v4M14 10v4h-4M6 14H2v-4" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          )}
        </button>

        {/* Pad ID badge */}
        {currentPadId && (
          <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-mono text-desk-muted bg-desk-panel border border-desk-border px-2 py-1 rounded">
            #{currentPadId}
          </span>
        )}
      </div>
    </header>
  )
}
