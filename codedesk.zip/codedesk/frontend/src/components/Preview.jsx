import React, { useEffect, useRef, useState, useCallback } from 'react'

function buildSrcDoc(html, css, js) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<style>
  *, *::before, *::after { box-sizing: border-box; }
  ${css}
</style>
</head>
<body>
${html}
<script>
// Intercept console
(function() {
  const _log = console.log.bind(console);
  const _warn = console.warn.bind(console);
  const _error = console.error.bind(console);
  const _info = console.info.bind(console);

  function serialize(args) {
    return args.map(a => {
      try { return typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a) }
      catch(_) { return String(a) }
    }).join(' ');
  }

  function post(type, args) {
    window.parent.postMessage({ type: 'console', level: type, message: serialize(args) }, '*');
  }

  console.log   = (...a) => { post('log',   a); _log(...a);   };
  console.warn  = (...a) => { post('warn',  a); _warn(...a);  };
  console.error = (...a) => { post('error', a); _error(...a); };
  console.info  = (...a) => { post('info',  a); _info(...a);  };

  window.onerror = (msg, src, line) => {
    post('error', [\`\${msg} (line \${line})\`]);
    return false;
  };
})();
<\/script>
<script>
${js}
<\/script>
</body>
</html>`
}

export default function Preview({ html, css, js, runTrigger }) {
  const iframeRef = useRef(null)
  const [srcDoc, setSrcDoc] = useState('')
  const [consoleLogs, setConsoleLogs] = useState([])
  const [showConsole, setShowConsole] = useState(false)
  const [consoleHeight, setConsoleHeight] = useState(140)

  // Update preview on runTrigger
  useEffect(() => {
    setSrcDoc(buildSrcDoc(html, css, js))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runTrigger])

  // Listen to console messages from iframe
  useEffect(() => {
    function handler(e) {
      if (e.data?.type === 'console') {
        setConsoleLogs(prev => [...prev.slice(-199), {
          level: e.data.level,
          message: e.data.message,
          ts: Date.now(),
        }])
        if (e.data.level === 'error') setShowConsole(true)
      }
    }
    window.addEventListener('message', handler)
    return () => window.removeEventListener('message', handler)
  }, [])

  const clearConsole = useCallback(() => setConsoleLogs([]), [])

  const levelClass = {
    log:   'console-log',
    warn:  'console-warn',
    error: 'console-error',
    info:  'console-info',
  }

  const levelIcon = {
    log:   '›',
    warn:  '⚠',
    error: '✕',
    info:  'ℹ',
  }

  return (
    <div className="flex flex-col h-full bg-desk-bg overflow-hidden">
      {/* Preview header */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-desk-border bg-desk-surface flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-desk-red/60" />
            <span className="w-2.5 h-2.5 rounded-full bg-desk-yellow/60" />
            <span className="w-2.5 h-2.5 rounded-full bg-desk-green/60" />
          </div>
          <span className="text-[11px] font-mono text-desk-muted ml-1">preview</span>
        </div>
        <div className="flex items-center gap-2">
          {consoleLogs.some(l => l.level === 'error') && (
            <span className="text-[10px] text-desk-red font-mono bg-desk-red/10 border border-desk-red/20 px-1.5 py-0.5 rounded">
              {consoleLogs.filter(l => l.level === 'error').length} error(s)
            </span>
          )}
          <button
            onClick={() => setShowConsole(v => !v)}
            className={`text-[11px] font-mono px-2 py-0.5 rounded transition-colors ${showConsole ? 'text-desk-accent bg-desk-accent/10' : 'text-desk-muted hover:text-desk-text-dim'}`}
          >
            console {consoleLogs.length > 0 && `(${consoleLogs.length})`}
          </button>
          <button
            onClick={() => setSrcDoc(buildSrcDoc(html, css, js))}
            className="text-desk-muted hover:text-desk-text-dim transition-colors"
            title="Refresh preview"
          >
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7">
              <path d="M3 8A5 5 0 1 1 5.5 12.5" strokeLinecap="round"/>
              <path d="M3 4.5V8.5H7" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>

      {/* iframe */}
      <div className="flex-1 overflow-hidden relative">
        {srcDoc ? (
          <iframe
            ref={iframeRef}
            srcDoc={srcDoc}
            title="Code Preview"
            sandbox="allow-scripts allow-same-origin allow-forms allow-modals allow-popups"
            className="w-full h-full border-0 bg-white"
          />
        ) : (
          <div className="flex items-center justify-center h-full text-desk-muted text-sm font-mono">
            Press Run to see your code here
          </div>
        )}
      </div>

      {/* Console panel */}
      {showConsole && (
        <div
          className="border-t border-desk-border bg-desk-surface flex flex-col flex-shrink-0 animate-fade-in"
          style={{ height: consoleHeight }}
        >
          <div className="flex items-center justify-between px-3 py-1 border-b border-desk-border flex-shrink-0">
            <span className="text-[10px] font-mono text-desk-muted uppercase tracking-widest">Console</span>
            <div className="flex items-center gap-2">
              <button onClick={clearConsole} className="text-[10px] font-mono text-desk-muted hover:text-desk-text-dim">
                clear
              </button>
              <button onClick={() => setShowConsole(false)} className="text-desk-muted hover:text-desk-text-dim">
                <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M2 2l8 8M10 2l-8 8"/>
                </svg>
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-1.5 font-mono text-[11.5px] space-y-0.5">
            {consoleLogs.length === 0 ? (
              <span className="text-desk-muted italic">No console output yet.</span>
            ) : (
              consoleLogs.map((log, i) => (
                <div key={i} className={`flex gap-2 items-start leading-5 ${levelClass[log.level] || 'console-log'}`}>
                  <span className="flex-shrink-0 opacity-70 w-3">{levelIcon[log.level]}</span>
                  <pre className="whitespace-pre-wrap break-all">{log.message}</pre>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  )
}
