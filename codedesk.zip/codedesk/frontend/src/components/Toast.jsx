import React, { useEffect } from 'react'

export default function Toast({ message, type = 'success', onClose }) {
  useEffect(() => {
    const t = setTimeout(onClose, 2800)
    return () => clearTimeout(t)
  }, [onClose])

  const colors = {
    success: 'border-desk-green/30 bg-desk-green/10 text-desk-green',
    error:   'border-desk-red/30 bg-desk-red/10 text-desk-red',
    info:    'border-desk-accent/30 bg-desk-accent/10 text-desk-accent',
  }

  const icons = {
    success: '✓',
    error:   '✕',
    info:    'ℹ',
  }

  return (
    <div className={`toast fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-lg border text-sm font-medium shadow-2xl ${colors[type]}`}>
      <span className="text-base leading-none">{icons[type]}</span>
      {message}
    </div>
  )
}
