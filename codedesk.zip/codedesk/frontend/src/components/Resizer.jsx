import React, { useRef, useCallback, useEffect, useState } from 'react'

export default function Resizer({ onResize }) {
  const [dragging, setDragging] = useState(false)
  const startX = useRef(0)

  const onMouseDown = useCallback((e) => {
    e.preventDefault()
    setDragging(true)
    startX.current = e.clientX
  }, [])

  useEffect(() => {
    if (!dragging) return

    function onMouseMove(e) {
      const delta = e.clientX - startX.current
      startX.current = e.clientX
      onResize(delta)
    }

    function onMouseUp() {
      setDragging(false)
    }

    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup', onMouseUp)
    return () => {
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('mouseup', onMouseUp)
    }
  }, [dragging, onResize])

  return (
    <div
      className={`resizer ${dragging ? 'dragging' : ''}`}
      onMouseDown={onMouseDown}
      title="Drag to resize"
    />
  )
}
