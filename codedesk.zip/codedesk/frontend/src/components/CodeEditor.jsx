import React, { useRef } from 'react'
import Editor from '@monaco-editor/react'

const TABS = [
  { key: 'html', label: 'HTML', lang: 'html', color: '#f87171' },
  { key: 'css',  label: 'CSS',  lang: 'css',  color: '#7c6af7' },
  { key: 'js',   label: 'JS',   lang: 'javascript', color: '#fbbf24' },
]

const MONACO_OPTIONS = {
  fontSize: 13.5,
  fontFamily: '"JetBrains Mono", "Fira Code", monospace',
  fontLigatures: true,
  lineHeight: 22,
  minimap: { enabled: false },
  scrollBeyondLastLine: false,
  wordWrap: 'on',
  tabSize: 2,
  insertSpaces: true,
  smoothScrolling: true,
  cursorBlinking: 'smooth',
  cursorSmoothCaretAnimation: 'on',
  padding: { top: 14, bottom: 14 },
  renderLineHighlight: 'gutter',
  overviewRulerLanes: 0,
  hideCursorInOverviewRuler: true,
  overviewRulerBorder: false,
  scrollbar: {
    verticalScrollbarSize: 6,
    horizontalScrollbarSize: 6,
  },
  bracketPairColorization: { enabled: true },
  'semanticHighlighting.enabled': true,
}

export default function CodeEditor({
  activeTab, setActiveTab,
  html, setHtml,
  css, setCss,
  js, setJs,
  isFullscreen,
  onRun,
}) {
  const editorRef = useRef(null)

  const values = { html, css, js }
  const setters = { html: setHtml, css: setCss, js: setJs }
  const tab = TABS.find(t => t.key === activeTab)

  function handleMount(editor, monaco) {
    editorRef.current = editor

    // Ctrl+Enter to run
    editor.addCommand(
      monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter,
      () => onRun()
    )

    // Define dark theme
    monaco.editor.defineTheme('codedesk', {
      base: 'vs-dark',
      inherit: true,
      rules: [
        { token: 'comment', foreground: '52525b', fontStyle: 'italic' },
        { token: 'keyword', foreground: '7c6af7' },
        { token: 'string', foreground: '4ade80' },
        { token: 'number', foreground: 'fbbf24' },
        { token: 'tag', foreground: 'f87171' },
        { token: 'attribute.name', foreground: '7c6af7' },
        { token: 'attribute.value', foreground: '4ade80' },
        { token: 'delimiter', foreground: '71717a' },
      ],
      colors: {
        'editor.background': '#0d0d0f',
        'editor.foreground': '#e4e4e7',
        'editor.lineHighlightBackground': '#141416',
        'editor.selectionBackground': '#7c6af720',
        'editor.inactiveSelectionBackground': '#7c6af710',
        'editorLineNumber.foreground': '#3f3f46',
        'editorLineNumber.activeForeground': '#7c6af7',
        'editorCursor.foreground': '#7c6af7',
        'editorGutter.background': '#0d0d0f',
        'editorWidget.background': '#141416',
        'editorSuggestWidget.background': '#141416',
        'editorSuggestWidget.border': '#252528',
        'editorSuggestWidget.selectedBackground': '#1a1a1e',
        'input.background': '#1a1a1e',
        'input.border': '#252528',
        'focusBorder': '#7c6af7',
        'scrollbar.shadow': '#00000000',
        'scrollbarSlider.background': '#25252840',
        'scrollbarSlider.hoverBackground': '#3f3f4640',
      },
    })
    monaco.editor.setTheme('codedesk')
  }

  return (
    <div className="flex flex-col h-full bg-desk-bg overflow-hidden">
      {/* Tab bar */}
      <div className="flex items-center border-b border-desk-border bg-desk-surface flex-shrink-0 px-1 pt-1 gap-0.5">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`tab rounded-t-md ${activeTab === t.key ? 'tab-active bg-desk-bg border-t border-l border-r border-desk-border' : 'tab-inactive'}`}
          >
            <span
              className="w-1.5 h-1.5 rounded-full inline-block mr-1.5 align-middle"
              style={{ background: t.color, opacity: activeTab === t.key ? 1 : 0.35 }}
            />
            {t.label}
          </button>
        ))}
        <div className="flex-1" />
        <span className="text-[10px] font-mono text-desk-muted pr-2 pb-1">
          Ctrl+Enter to run
        </span>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-hidden">
        <Editor
          height="100%"
          language={tab.lang}
          value={values[activeTab]}
          onChange={(val) => setters[activeTab](val ?? '')}
          onMount={handleMount}
          options={MONACO_OPTIONS}
          loading={
            <div className="flex items-center justify-center h-full text-desk-muted text-sm font-mono">
              Loading editor…
            </div>
          }
        />
      </div>
    </div>
  )
}
