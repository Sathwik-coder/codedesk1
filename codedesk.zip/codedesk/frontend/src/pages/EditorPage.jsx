import React, { useState, useCallback, useRef, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import TopBar from '../components/TopBar'
import CodeEditor from '../components/CodeEditor'
import Preview from '../components/Preview'
import Resizer from '../components/Resizer'
import Toast from '../components/Toast'
import { usePad } from '../hooks/usePad'

export default function EditorPage() {
  const { id } = useParams()
  const {
    html, setHtml,
    css, setCss,
    js, setJs,
    currentPadId,
    saving, loading, error,
    share, reset,
  } = usePad(id)

  const [activeTab, setActiveTab] = useState('html')
  const [autoRun, setAutoRun] = useState(true)
  const [runTrigger, setRunTrigger] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [toast, setToast] = useState(null)
  const [splitPct, setSplitPct] = useState(50) // % for editor
  const containerRef = useRef(null)

  const showToast = useCallback((message, type = 'success') => {
    setToast({ message, type, key: Date.now() })
  }, [])

  // Run on mount
  useEffect(() => { setRunTrigger(t => t + 1) }, [])

  // Auto-run when code changes
  useEffect(() => {
    if (!autoRun) return
    const t = setTimeout(() => setRunTrigger(n => n + 1), 600)
    return () => clearTimeout(t)
  }, [html, css, js, autoRun])

  // Show errors from loading
  useEffect(() => {
    if (error) showToast(error, 'error')
  }, [error])

  const handleRun = useCallback(() => setRunTrigger(n => n + 1), [])

  const handleShare = useCallback(async () => {
    try {
      const url = await share()
      showToast(`Link copied! ${url}`, 'success')
    } catch {
      showToast('Share failed — check your connection', 'error')
    }
  }, [share, showToast])

  const handleReset = useCallback(() => {
    if (window.confirm('Reset all code to defaults?')) {
      reset()
      showToast('Reset to defaults', 'info')
    }
  }, [reset, showToast])

  const handleDownload = useCallback(() => {
    const content = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>CodeDesk Export</title>
<style>
${css}
</style>
</head>
<body>
${html}
<script>
${js}
<\/script>
</body>
</html>`
    const blob = new Blob([content], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `codedesk-${currentPadId || 'export'}.html`
    a.click()
    URL.revokeObjectURL(url)
    showToast('Downloaded!', 'success')
  }, [html, css, js, currentPadId, showToast])

  const handleResize = useCallback((delta) => {
    if (!containerRef.current) return
    const totalW = containerRef.current.offsetWidth
    setSplitPct(prev => {
      const newPct = prev + (delta / totalW) * 100
      return Math.max(20, Math.min(80, newPct))
    })
  }, [])

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-desk-bg">
        <div className="flex items-center gap-3 text-desk-muted font-mono text-sm">
          <div className="w-4 h-4 border-2 border-desk-accent/30 border-t-desk-accent rounded-full animate-spin" />
          Loading pad…
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen bg-desk-bg overflow-hidden">
      {!isFullscreen && (
        <TopBar
          saving={saving}
          autoRun={autoRun}
          onToggleAutoRun={() => setAutoRun(v => !v)}
          onRun={handleRun}
          onShare={handleShare}
          onReset={handleReset}
          onDownload={handleDownload}
          currentPadId={currentPadId}
          isFullscreen={isFullscreen}
          onToggleFullscreen={() => setIsFullscreen(v => !v)}
        />
      )}

      {/* Main split layout */}
      <div ref={containerRef} className="flex flex-1 overflow-hidden relative">
        {/* Editor pane */}
        <div
          className={`flex flex-col overflow-hidden ${isFullscreen ? 'fullscreen-editor' : ''}`}
          style={isFullscreen ? {} : { width: `${splitPct}%` }}
        >
          {isFullscreen && (
            <div className="flex items-center justify-between px-3 py-1.5 bg-desk-surface border-b border-desk-border flex-shrink-0">
              <span className="text-[11px] font-mono text-desk-muted">fullscreen mode</span>
              <button
                onClick={() => setIsFullscreen(false)}
                className="text-desk-muted hover:text-desk-text text-xs font-mono transition-colors"
              >
                esc to exit
              </button>
            </div>
          )}
          <CodeEditor
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            html={html} setHtml={setHtml}
            css={css}   setCss={setCss}
            js={js}     setJs={setJs}
            isFullscreen={isFullscreen}
            onRun={handleRun}
          />
          {isFullscreen && (
            <div className="absolute bottom-4 right-4 flex gap-2">
              <button onClick={handleRun} className="btn-primary text-xs shadow-xl">
                Run
              </button>
              <button onClick={() => setIsFullscreen(false)} className="btn-ghost text-xs shadow-xl">
                Exit
              </button>
            </div>
          )}
        </div>

        {/* Resizer */}
        {!isFullscreen && <Resizer onResize={handleResize} />}

        {/* Preview pane */}
        {!isFullscreen && (
          <div className="flex-1 overflow-hidden">
            <Preview
              html={html}
              css={css}
              js={js}
              runTrigger={runTrigger}
            />
          </div>
        )}
      </div>

      {/* Toast */}
      {toast && (
        <Toast
          key={toast.key}
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  )
}
