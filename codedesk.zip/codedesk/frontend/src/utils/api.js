import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:4000',
  timeout: 10000,
})

export const createPad = (data) => api.post('/pad', data)
export const getPad = (id) => api.get(`/pad/${id}`)
export const updatePad = (id, data) => api.put(`/pad/${id}`, data)

export default api
