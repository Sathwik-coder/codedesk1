/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        mono: ['"JetBrains Mono"', 'Fira Code', 'monospace'],
        sans: ['"DM Sans"', 'sans-serif'],
      },
      colors: {
        desk: {
          bg: '#0d0d0f',
          surface: '#141416',
          panel: '#1a1a1e',
          border: '#252528',
          accent: '#7c6af7',
          'accent-dim': '#5c4dd6',
          muted: '#52525b',
          text: '#e4e4e7',
          'text-dim': '#a1a1aa',
          green: '#4ade80',
          red: '#f87171',
          yellow: '#fbbf24',
        },
      },
      animation: {
        'fade-in': 'fadeIn 0.2s ease-out',
        'slide-up': 'slideUp 0.25s ease-out',
        pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideUp: { from: { opacity: 0, transform: 'translateY(6px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
      },
    },
  },
  plugins: [],
}
