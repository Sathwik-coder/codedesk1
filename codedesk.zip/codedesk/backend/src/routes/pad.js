const express = require('express');
const router = express.Router();
const { nanoid } = require('nanoid');
const Pad = require('../models/Pad');

// POST /pad — create new pad
router.post('/', async (req, res) => {
  try {
    const { html = '', css = '', js = '' } = req.body;
    const id = nanoid(8);

    const pad = new Pad({ id, html, css, js });
    await pad.save();

    res.status(201).json({ id, html, css, js, createdAt: pad.createdAt });
  } catch (err) {
    console.error('Create pad error:', err);
    res.status(500).json({ error: 'Failed to create pad' });
  }
});

// GET /pad/:id — load pad
router.get('/:id', async (req, res) => {
  try {
    const pad = await Pad.findOne({ id: req.params.id });
    if (!pad) return res.status(404).json({ error: 'Pad not found' });

    res.json({ id: pad.id, html: pad.html, css: pad.css, js: pad.js, createdAt: pad.createdAt });
  } catch (err) {
    console.error('Get pad error:', err);
    res.status(500).json({ error: 'Failed to load pad' });
  }
});

// PUT /pad/:id — update pad
router.put('/:id', async (req, res) => {
  try {
    const { html, css, js } = req.body;
    const pad = await Pad.findOne({ id: req.params.id });
    if (!pad) return res.status(404).json({ error: 'Pad not found' });

    if (html !== undefined) pad.html = html;
    if (css !== undefined) pad.css = css;
    if (js !== undefined) pad.js = js;
    pad.updatedAt = Date.now();
    await pad.save();

    res.json({ id: pad.id, html: pad.html, css: pad.css, js: pad.js });
  } catch (err) {
    console.error('Update pad error:', err);
    res.status(500).json({ error: 'Failed to update pad' });
  }
});

module.exports = router;
