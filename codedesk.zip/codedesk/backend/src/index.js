require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const padRoutes = require('./routes/pad');

const app = express();
const PORT = process.env.PORT || 4000;

// CORS
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:5173',
    /\.vercel\.app$/,
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true,
}));

app.use(express.json({ limit: '2mb' }));

// Health check
app.get('/', (req, res) => res.json({ status: 'CodeDesk API running 🚀' }));

// Routes
app.use('/pad', padRoutes);

// 404
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// Connect to MongoDB then start server
mongoose
  .connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/codedesk')
  .then(() => {
    console.log('✅ MongoDB connected');
    app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
  })
  .catch((err) => {
    console.error('❌ MongoDB connection failed:', err.message);
    process.exit(1);
  });
